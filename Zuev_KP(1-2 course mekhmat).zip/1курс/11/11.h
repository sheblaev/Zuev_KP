double uravn(double a, double b, double ep, double alpha);
double modul(double x);

