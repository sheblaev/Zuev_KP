typedef double (*RRFUN) (double x);

double taylor(double x, double ep, RRFUN ffunc);


