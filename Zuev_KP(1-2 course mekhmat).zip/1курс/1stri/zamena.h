void zamena(FILE *input1, FILE *output);

