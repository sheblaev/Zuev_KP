typedef double (*RRFUN) (double x);

double minimum(double a, double b, double ep, RRFUN ffunc);


