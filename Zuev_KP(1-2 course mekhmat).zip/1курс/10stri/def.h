void def(FILE *input, FILE *output, const char *def, const char *und);





