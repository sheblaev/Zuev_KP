double* clin(double **mas, int n_rows, int n_cols, double *x);


