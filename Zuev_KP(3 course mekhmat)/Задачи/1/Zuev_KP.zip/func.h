double func(int s, int n, int i, int j);
double modul(double x);
void vvod(double *mas, int s, int n, char* a);
double *gauss(int n, int m, double *mas, double *b, double *x);
