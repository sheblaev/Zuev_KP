void reduce_sum(int p, int *a, double *b);

class Args
{
        public:
                char *f=nullptr;
                int m=0;
                int error=0;
                int p=0;
                int res0=0;
                double res=0;
                int res1=0;
};
