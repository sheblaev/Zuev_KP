void reduce_sum(int p);

class Args
{
        public:
                char *f=nullptr;
                int m=0;
                int error=0;
                int p=0;
                int res=0;
};
