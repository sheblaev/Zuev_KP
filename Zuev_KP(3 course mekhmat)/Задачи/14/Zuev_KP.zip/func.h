double func(int s, int n, int i, int j);
void vvod(double *mas, int s, int n, char* a);
double *rotation(int n, double *mas, double e);
int bisection(int n, double *mas, double *x, double e);
int number(int n, double *mas, double l, double max);
